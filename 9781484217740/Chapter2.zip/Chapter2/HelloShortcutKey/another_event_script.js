//region {variables and functions}
var consoleGreeting = "Hello World! - from another_event_script.js";
var details = {"path":"icon-2.png"};
//end-region



//region {calls}
console.log(consoleGreeting);
//end-region