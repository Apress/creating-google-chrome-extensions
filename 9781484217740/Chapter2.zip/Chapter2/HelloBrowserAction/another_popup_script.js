//region {variables and functions}
var consoleGreeting = "Hello World Again! - from another_popup_script.js";
//end-region



//region {calls}
console.log(consoleGreeting);
//end-region